package com.badmintoncam.game;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.Image;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.pose.Pose;
import com.google.mlkit.vision.pose.PoseDetection;
import com.google.mlkit.vision.pose.PoseDetector;
import com.google.mlkit.vision.pose.PoseLandmark;
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements GameRenderer.Ui {
 GLSurfaceView gl;GameRenderer rd=new GameRenderer();TextView tvS,tvM,tvT,tvL,tvC;PoseDetector det;
 boolean cal;int calN;float acx,at,cx0,t0;float[] pw;long pt,lastSw;

 TextView tv(FrameLayout f,int sp,int grav){TextView t=new TextView(this);t.setTextSize(sp);t.setTextColor(Color.WHITE);t.setShadowLayer(6,0,0,Color.BLACK);t.setPadding(24,12,24,12);f.addView(t,new FrameLayout.LayoutParams(-2,-2,grav));return t;}
 @Override protected void onCreate(Bundle b){super.onCreate(b);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
  FrameLayout f=new FrameLayout(this);gl=new GLSurfaceView(this);gl.setEGLContextClientVersion(2);rd.ui=this;gl.setRenderer(rd);f.addView(gl);
  tvS=tv(f,34,Gravity.TOP|Gravity.CENTER_HORIZONTAL);tvM=tv(f,26,Gravity.CENTER);tvT=tv(f,14,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
  tvL=tv(f,13,Gravity.TOP|Gravity.START);tvL.setText("TUM = neela player | OPPONENT (AI) = laal player");
  tvC=tv(f,14,Gravity.BOTTOM|Gravity.START);tvC.setText("[ Recalibrate ]");tvC.setOnClickListener(v->{cal=false;calN=0;acx=at=0;tvT.setText("Seedha khade ho, calibrate ho raha hai...");});
  tvM.setText("Tap karo shuru karne ke liye");tvS.setText("0 : 0");
  gl.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){if(rd.mode==0||rd.mode==4)gl.queueEvent(()->rd.start());else rd.swing(.55f);}return true;});
  setContentView(f);
  det=PoseDetection.getClient(new PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build());
  if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)cam();else ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},1);}
 @Override public void onRequestPermissionsResult(int c,String[] p,int[] r){super.onRequestPermissionsResult(c,p,r);if(r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)cam();else tvT.setText("Camera permission do. Tab se bhi khel sakte ho.");}
 @Override protected void onResume(){super.onResume();gl.onResume();}
 @Override protected void onPause(){super.onPause();gl.onPause();}
 public void msg(String s){runOnUiThread(()->tvM.setText(s));}
 public void score(int a,int b){runOnUiThread(()->tvS.setText(a+" : "+b));}
 void st(String s){runOnUiThread(()->tvT.setText(s));}
 void cam(){tvT.setText("Seedha khade ho, calibrate ho raha hai...");
  ListenableFuture<ProcessCameraProvider> fu=ProcessCameraProvider.getInstance(this);
  fu.addListener(()->{try{ProcessCameraProvider p=fu.get();
   ImageAnalysis ia=new ImageAnalysis.Builder().setTargetResolution(new Size(640,480)).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
   ia.setAnalyzer(Executors.newSingleThreadExecutor(),ip->analyze(ip));
   p.unbindAll();p.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,ia);}catch(Exception e){st("Camera error: "+e.getMessage());}},ContextCompat.getMainExecutor(this));}
 @androidx.camera.core.ExperimentalGetImage
 void analyze(ImageProxy ip){Image im=ip.getImage();if(im==null){ip.close();return;}
  int rot=ip.getImageInfo().getRotationDegrees();final float uw=rot%180==0?ip.getWidth():ip.getHeight(),uh=rot%180==0?ip.getHeight():ip.getWidth();
  det.process(InputImage.fromMediaImage(im,rot)).addOnSuccessListener(po->pose(po,uw,uh)).addOnCompleteListener(t->ip.close());}
 boolean ok(PoseLandmark l){return l!=null&&l.getInFrameLikelihood()>.5f;}
 void pose(Pose po,float uw,float uh){
  PoseLandmark ls=po.getPoseLandmark(PoseLandmark.LEFT_SHOULDER),rs=po.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER),lh=po.getPoseLandmark(PoseLandmark.LEFT_HIP),rh=po.getPoseLandmark(PoseLandmark.RIGHT_HIP),lw=po.getPoseLandmark(PoseLandmark.LEFT_WRIST),rw=po.getPoseLandmark(PoseLandmark.RIGHT_WRIST);
  if(!(ok(ls)&&ok(rs)&&ok(lh)&&ok(rh))){st("Body nahi dikh rahi. Poora body camera mein rakho.");return;}
  float sx=(ls.getPosition().x+rs.getPosition().x)/2,sy=(ls.getPosition().y+rs.getPosition().y)/2,hx=(lh.getPosition().x+rh.getPosition().x)/2,hy=(lh.getPosition().y+rh.getPosition().y)/2;
  float tp=(float)Math.hypot(sx-hx,sy-hy),torso=tp/uh,cx=sx/uw;
  if(!cal){acx+=cx;at+=torso;if(++calN>=20){cx0=acx/calN;t0=at/calN;cal=true;st("Ready! Aage/peeche aur left/right chalo, swing karo.");}return;}
  rd.poseX=-(cx-cx0)*10f;rd.poseZ=4.5f-(torso/t0-1)*10f;rd.poseOk=true;
  if(!ok(lw)||!ok(rw))return;
  long now=System.nanoTime();float[] w={lw.getPosition().x,lw.getPosition().y,rw.getPosition().x,rw.getPosition().y};
  if(pw!=null){float dt=(now-pt)/1e9f;if(dt>.01f){float v=(float)Math.max(Math.hypot(w[0]-pw[0],w[1]-pw[1]),Math.hypot(w[2]-pw[2],w[3]-pw[3]))/tp/dt;
   if(v>5f&&now-lastSw>350000000L){rd.swing(Math.min(1f,(v-5f)/12f));lastSw=now;}}}
  pw=w;pt=now;}
}
