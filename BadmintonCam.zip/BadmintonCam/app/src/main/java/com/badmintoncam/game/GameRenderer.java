package com.badmintoncam.game;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameRenderer implements GLSurfaceView.Renderer {
 public interface Ui{void msg(String s);void score(int a,int b);}
 public Ui ui;
 public volatile float poseX=0,poseZ=4.5f;public volatile boolean poseOk;
 public volatile int mode; // 0 menu,1 player serve,2 fly,3 point,4 over,5 ai serve
 Random rnd=new Random();
 int prog,aP,aN,uM,uC;FloatBuffer vb;
 float[] proj=new float[16],view=new float[16],vp=new float[16],t1=new float[16],t2=new float[16],t3=new float[16],B=new float[16];
 float px=0,pz=4.5f,ox=0,oz=-4.5f,bx,by=1,bz,bvx,bvy,bvz,swA,aiA,tm,pendT,pendP,aiRoll;
 int last,srv,sA,sB;boolean aiDone;long lt=System.nanoTime();

 float r(float a,float b){return a+rnd.nextFloat()*(b-a);}
 float cl(float v,float m){return Math.max(-m,Math.min(m,v));}
 public void swing(float p){swA=1;pendP=p;pendT=.3f;}
 public void start(){sA=sB=0;srv=0;ox=0;oz=-4.5f;ui.score(0,0);next();}
 void next(){ox=0;oz=-4.5f;last=srv==0?0:1;if(srv==0){mode=1;ui.msg("Swing karo = serve");}else{mode=5;tm=1.2f;ui.msg("");}}
 void launch(float tx,float tz,float T){bvx=(tx-bx)/T;bvz=(tz-bz)/T;bvy=(.03f-by+4.9f*T*T)/T;}
 void point(int w,String why){mode=3;tm=1.6f;if(w==0)sA++;else sB++;srv=w;ui.score(sA,sB);ui.msg((w==0?"Tumhara point! ":"Opponent ka point ")+why);}
 void hit(){
  if(mode==1){bx=px;by=1.1f;bz=pz-.5f;launch(r(-1.5f,1.5f),-5.3f,1.5f);last=0;mode=2;pendT=0;aiDone=false;aiRoll=rnd.nextFloat();ui.msg("");return;}
  if(mode==2&&last==1&&bz>0&&by>.15f&&by<2.9f&&Math.hypot(bx-px,bz-pz)<1.3){
   int s=pendP<.35f?0:pendP<.7f?1:2;
   if(s==0)launch(r(-2,2),r(-1.4f,-.9f),1.1f);else if(s==1)launch(r(-2.5f,2.5f),r(-6,-5),1.5f);else launch(r(-2.5f,2.5f),r(-5,-3),.6f);
   last=0;pendT=0;aiDone=false;aiRoll=rnd.nextFloat();ui.msg(s==0?"Drop":s==1?"Clear":"SMASH!");}}
 void aiHit(){float x=r(-2.6f,2.6f);aiA=1;last=1;aiDone=true;
  if(by>1.8f&&rnd.nextFloat()<.3f)launch(x,r(2,5),.6f);else if(by<1.3f||rnd.nextFloat()<.6f)launch(x,r(3.5f,6),1.5f);else launch(x,r(.9f,1.8f),1.1f);}
 void upd(float dt){
  swA=Math.max(0,swA-dt*3);aiA=Math.max(0,aiA-dt*3);
  if(poseOk){float a=Math.min(1,dt*9);px+=(Math.max(-2.9f,Math.min(2.9f,poseX))-px)*a;pz+=(Math.max(1f,Math.min(6.3f,poseZ))-pz)*a;}
  if(mode==0||mode==4)return;
  if(pendT>0){pendT-=dt;hit();}
  if(mode==3){tm-=dt;if(tm<=0){if(sA>=11||sB>=11){mode=4;ui.msg((sA>sB?"Tum jeet gaye! ":"Opponent jeeta. ")+"Tap karke dobara khelo");}else next();}return;}
  if(mode==1){bx=px;by=1.1f+(float)Math.sin(System.nanoTime()/2e8)*.03f;bz=pz-.5f;return;}
  if(mode==5){tm-=dt;bx=ox;by=1.2f;bz=oz+.5f;if(tm<=0){aiA=1;launch(r(-2,2),r(3.5f,5.5f),1.4f);last=1;mode=2;aiDone=false;aiRoll=rnd.nextFloat();}return;}
  float z0=bz;bvy-=9.8f*dt;bx+=bvx*dt;by+=bvy*dt;bz+=bvz*dt;
  if((z0>0)!=(bz>0)&&by<1.55f){point(1-last,"(net)");return;}
  if(by<=.03f){by=.03f;if(Math.abs(bx)>3.05f||Math.abs(bz)>6.7f)point(1-last,"(out)");else point(bz<0?0:1,"");return;}
  float sp=4.2f*dt;
  if(last==0){ox+=cl(bx-ox,sp);oz+=cl(Math.min(-.9f,Math.max(-6.3f,bz))-oz,sp);}else{ox+=cl(-ox,sp*.5f);oz+=cl(-4.5f-oz,sp*.5f);}
  if(last==0&&!aiDone&&bz<0&&bvy<0&&by<2.6f&&by>.2f&&Math.hypot(bx-ox,bz-oz)<1.2){aiDone=true;if(aiRoll<.82f)aiHit();}}

 static int sh(int t,String s){int h=GLES20.glCreateShader(t);GLES20.glShaderSource(h,s);GLES20.glCompileShader(h);return h;}
 public void onSurfaceCreated(GL10 g,EGLConfig c){
  GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glEnable(GLES20.GL_BLEND);GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA);GLES20.glClearColor(.05f,.08f,.16f,1);
  prog=GLES20.glCreateProgram();
  GLES20.glAttachShader(prog,sh(GLES20.GL_VERTEX_SHADER,"uniform mat4 uM;uniform vec4 uC;attribute vec3 aP;attribute vec3 aN;varying vec4 vC;void main(){vC=vec4(uC.rgb*(.45+.55*max(dot(aN,normalize(vec3(.4,1.,.5))),0.)),uC.a);gl_Position=uM*vec4(aP,1.);}"));
  GLES20.glAttachShader(prog,sh(GLES20.GL_FRAGMENT_SHADER,"precision mediump float;varying vec4 vC;void main(){gl_FragColor=vC;}"));
  GLES20.glLinkProgram(prog);GLES20.glUseProgram(prog);
  aP=GLES20.glGetAttribLocation(prog,"aP");aN=GLES20.glGetAttribLocation(prog,"aN");uM=GLES20.glGetUniformLocation(prog,"uM");uC=GLES20.glGetUniformLocation(prog,"uC");
  float[] d=new float[216];int k=0;int[][] cs={{-1,-1},{1,-1},{1,1},{-1,1}};int[] ix={0,1,2,0,2,3};
  for(int f=0;f<6;f++){int a=f/2,u=(a+1)%3,v=(a+2)%3;float s=f%2==0?1:-1;
   for(int q:ix){float[] p=new float[3],n=new float[3];p[a]=s*.5f;p[u]=cs[q][0]*.5f;p[v]=cs[q][1]*.5f;n[a]=s;for(int i=0;i<3;i++)d[k++]=p[i];for(int i=0;i<3;i++)d[k++]=n[i];}}
  vb=ByteBuffer.allocateDirect(d.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer();vb.put(d);}
 public void onSurfaceChanged(GL10 g,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(proj,0,52,(float)w/h,.1f,60);}
 void drawM(float[] m,float rr,float gg,float bb,float a){Matrix.multiplyMM(t3,0,vp,0,m,0);GLES20.glUniformMatrix4fv(uM,1,false,t3,0);GLES20.glUniform4f(uC,rr,gg,bb,a);GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36);}
 void box(float x,float y,float z,float w,float h,float d,float rr,float gg,float bb,float a){Matrix.setIdentityM(t1,0);Matrix.translateM(t1,0,x,y,z);Matrix.scaleM(t1,0,w,h,d);drawM(t1,rr,gg,bb,a);}
 void part(float x,float y,float z,float rx,float oy,float w,float h,float d,float rr,float gg,float bb){Matrix.setIdentityM(t1,0);Matrix.translateM(t1,0,x,y,z);Matrix.rotateM(t1,0,rx,1,0,0);Matrix.translateM(t1,0,0,oy,0);Matrix.scaleM(t1,0,w,h,d);Matrix.multiplyMM(t2,0,B,0,t1,0);drawM(t2,rr,gg,bb,1);}
 void fig(float x,float z,float face,float sw,float cr,float cg,float cb){
  Matrix.setIdentityM(B,0);Matrix.translateM(B,0,x,0,z);Matrix.rotateM(B,0,face,0,1,0);
  part(-.14f,.45f,0,0,0,.14f,.9f,.16f,.12f,.12f,.2f);part(.14f,.45f,0,0,0,.14f,.9f,.16f,.12f,.12f,.2f);
  part(0,1.2f,0,0,0,.5f,.6f,.25f,cr,cg,cb);part(0,1.7f,0,0,0,.22f,.24f,.22f,.95f,.8f,.65f);
  float th=sw>0?70+140*sw:190;
  part(.3f,1.45f,0,th,-.3f,.1f,.6f,.1f,cr,cg,cb);part(.3f,1.45f,0,th,-.75f,.04f,.5f,.04f,.8f,.8f,.8f);part(.3f,1.45f,0,th,-1.15f,.28f,.34f,.03f,.95f,.9f,.2f);}
 public void onDrawFrame(GL10 g){
  long n=System.nanoTime();float dt=Math.min(.05f,(n-lt)/1e9f);lt=n;upd(dt);
  GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
  vb.position(0);GLES20.glVertexAttribPointer(aP,3,GLES20.GL_FLOAT,false,24,vb);GLES20.glEnableVertexAttribArray(aP);
  vb.position(3);GLES20.glVertexAttribPointer(aN,3,GLES20.GL_FLOAT,false,24,vb);GLES20.glEnableVertexAttribArray(aN);
  Matrix.setLookAtM(view,0,px*.35f,4.8f,pz+6.3f,px*.2f,.5f,-2f,0,1,0);Matrix.multiplyMM(vp,0,proj,0,view,0);
  box(0,-.05f,0,18,.1f,24,.1f,.2f,.3f,1);box(0,0,0,6.1f,.02f,13.4f,.12f,.42f,.36f,1);box(0,3,-10,20,6,.2f,.08f,.1f,.2f,1);
  float l=.05f;box(-3.05f,.02f,0,l,.01f,13.4f,1,1,1,1);box(3.05f,.02f,0,l,.01f,13.4f,1,1,1,1);box(0,.02f,6.7f,6.1f,.01f,l,1,1,1,1);box(0,.02f,-6.7f,6.1f,.01f,l,1,1,1,1);box(0,.02f,1.98f,6.1f,.01f,l,1,1,1,1);box(0,.02f,-1.98f,6.1f,.01f,l,1,1,1,1);
  box(-3.05f,.775f,0,.06f,1.55f,.06f,.8f,.8f,.8f,1);box(3.05f,.775f,0,.06f,1.55f,.06f,.8f,.8f,.8f,1);box(0,1.2f,0,6.1f,.7f,.02f,.1f,.1f,.1f,.55f);box(0,1.55f,0,6.1f,.05f,.03f,1,1,1,1);
  box(px,.03f,pz,.7f,.01f,.5f,0,0,0,.35f);box(ox,.03f,oz,.7f,.01f,.5f,0,0,0,.35f);
  fig(px,pz,0,swA,.2f,.5f,1f);fig(ox,oz,180,aiA,1f,.3f,.3f);
  if(mode!=0&&mode!=4){box(bx,.035f,bz,.22f,.01f,.22f,0,0,0,.45f);box(bx,by,bz,.12f,.12f,.12f,.95f,.95f,.95f,1);box(bx,by+.1f,bz,.24f,.14f,.24f,.9f,.9f,1,1);}}
}
