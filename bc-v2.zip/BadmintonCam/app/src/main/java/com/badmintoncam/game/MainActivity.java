package com.badmintoncam.game;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.Image;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.pose.Pose;
import com.google.mlkit.vision.pose.PoseDetection;
import com.google.mlkit.vision.pose.PoseDetector;
import com.google.mlkit.vision.pose.PoseLandmark;
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements GameRenderer.Ui {
 GLSurfaceView gl;GameRenderer rd=new GameRenderer();TextView tvS,tvM,tvT,tvL,tvC,tvK;PoseDetector det;
 boolean cal;int calN;float acx,at,cx0,t0;long lastSw,holdT;float[][] hx=new float[2][8],hy=new float[2][8];long[][] ht=new long[2][8];int hn;

 TextView tv(FrameLayout f,int sp,int grav){TextView t=new TextView(this);t.setTextSize(sp);t.setTextColor(Color.WHITE);t.setShadowLayer(6,0,0,Color.BLACK);t.setPadding(24,12,24,12);f.addView(t,new FrameLayout.LayoutParams(-2,-2,grav));return t;}
 @Override protected void onCreate(Bundle b){super.onCreate(b);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
  FrameLayout f=new FrameLayout(this);gl=new GLSurfaceView(this);gl.setEGLContextClientVersion(2);rd.ui=this;gl.setRenderer(rd);f.addView(gl);
  tvS=tv(f,34,Gravity.TOP|Gravity.CENTER_HORIZONTAL);tvM=tv(f,26,Gravity.CENTER);tvT=tv(f,14,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
  tvL=tv(f,13,Gravity.TOP|Gravity.START);tvL.setText("TUM = neela player | OPPONENT (AI) = laal player");
  tvC=tv(f,14,Gravity.BOTTOM|Gravity.START);tvC.setText("[ Recalibrate ]");tvC.setOnClickListener(v->recal());
  tvK=tv(f,14,Gravity.BOTTOM|Gravity.END);tvK.setText("[ TV par bhejo ]");tvK.setOnClickListener(v->cast());
  tvM.setText("Haath upar karo (ya tap karo) = game shuru");tvS.setText("0 : 0");
  gl.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){if(rd.mode==0||rd.mode==4)gl.queueEvent(()->rd.start());else rd.swing(.55f);}return true;});
  setContentView(f);
  det=PoseDetection.getClient(new PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build());
  if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)cam();else ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},1);}
 @Override public void onRequestPermissionsResult(int c,String[] p,int[] r){super.onRequestPermissionsResult(c,p,r);if(r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)cam();else tvT.setText("Camera permission do. Tab se bhi khel sakte ho.");}
 @Override protected void onResume(){super.onResume();gl.onResume();}
 @Override protected void onPause(){super.onPause();gl.onPause();}
 public void msg(String s){runOnUiThread(()->tvM.setText(s));}
 public void score(int a,int b){runOnUiThread(()->tvS.setText(a+" : "+b));}
 void st(String s){runOnUiThread(()->tvT.setText(s));}
 void cam(){tvT.setText("Seedha khade ho, calibrate ho raha hai...");
  ListenableFuture<ProcessCameraProvider> fu=ProcessCameraProvider.getInstance(this);
  fu.addListener(()->{try{ProcessCameraProvider p=fu.get();
   ImageAnalysis ia=new ImageAnalysis.Builder().setTargetResolution(new Size(480,360)).setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
   ia.setAnalyzer(Executors.newSingleThreadExecutor(),ip->analyze(ip));
   p.unbindAll();p.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,ia);}catch(Exception e){st("Camera error: "+e.getMessage());}},ContextCompat.getMainExecutor(this));}
 @androidx.camera.core.ExperimentalGetImage
 void analyze(ImageProxy ip){Image im=ip.getImage();if(im==null){ip.close();return;}
  int rot=ip.getImageInfo().getRotationDegrees();final float uw=rot%180==0?ip.getWidth():ip.getHeight(),uh=rot%180==0?ip.getHeight():ip.getWidth();
  det.process(InputImage.fromMediaImage(im,rot)).addOnSuccessListener(po->pose(po,uw,uh)).addOnCompleteListener(t->ip.close());}
 boolean ok(PoseLandmark l){return l!=null&&l.getInFrameLikelihood()>.5f;}
 void recal(){cal=false;calN=0;acx=at=0;st("Seedha khade ho, calibrate ho raha hai...");}
 void cast(){try{startActivity(new Intent("android.settings.CAST_SETTINGS"));}catch(Exception e){Toast.makeText(this,"Upar se swipe karo, Quick Settings mein Cast / Smart View dabao aur TV chuno",Toast.LENGTH_LONG).show();}}
 void pose(Pose po,float uw,float uh){
  PoseLandmark ls=po.getPoseLandmark(PoseLandmark.LEFT_SHOULDER),rs=po.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER),lh=po.getPoseLandmark(PoseLandmark.LEFT_HIP),rh=po.getPoseLandmark(PoseLandmark.RIGHT_HIP),lw=po.getPoseLandmark(PoseLandmark.LEFT_WRIST),rw=po.getPoseLandmark(PoseLandmark.RIGHT_WRIST);
  if(!(ok(ls)&&ok(rs)&&ok(lh)&&ok(rh))){st("Body nahi dikh rahi. Poora body camera mein rakho.");return;}
  float sx=(ls.getPosition().x+rs.getPosition().x)/2,sy=(ls.getPosition().y+rs.getPosition().y)/2,mx=(lh.getPosition().x+rh.getPosition().x)/2,my=(lh.getPosition().y+rh.getPosition().y)/2;
  float tp=(float)Math.hypot(sx-mx,sy-my),torso=tp/uh,cx=sx/uw;
  if(!cal){acx+=cx;at+=torso;if(++calN>=20){cx0=acx/calN;t0=at/calN;cal=true;st("Ready! Haath upar karo = game shuru");}return;}
  rd.poseX=-(cx-cx0)*10f;rd.poseZ=4.5f-(torso/t0-1)*10f;rd.poseOk=true;
  if(lw==null||rw==null)return;
  long now=System.nanoTime();int i=hn%8;hn++;
  float[] wx={lw.getPosition().x,rw.getPosition().x},wy={lw.getPosition().y,rw.getPosition().y};
  for(int k=0;k<2;k++){hx[k][i]=(wx[k]-sx)/tp;hy[k][i]=(wy[k]-sy)/tp;ht[k][i]=now;}
  boolean menu=rd.mode==0||rd.mode==4;
  boolean lu=wy[0]<sy-.9f*tp,ru=wy[1]<sy-.9f*tp;
  if(menu){
   st("Haath upar karo = game shuru | dono haath = recalibrate");
   if(lu||ru){if(holdT==0)holdT=now;else if(now-holdT>700000000L){holdT=0;lastSw=now;if(lu&&ru)recal();else gl.queueEvent(()->rd.start());}}else holdT=0;
   return;}
  holdT=0;float best=0;
  if(now-lastSw>450000000L){
   for(int k=0;k<2;k++)for(int j=0;j<8;j++){if(j==i||ht[k][j]==0||now-ht[k][j]>300000000L)continue;float d=(float)Math.hypot(hx[k][i]-hx[k][j],hy[k][i]-hy[k][j]);if(d>best)best=d;}
   if(best>.8f){rd.swing(Math.min(1f,(best-.8f)/1.2f));lastSw=now;for(int k=0;k<2;k++)java.util.Arrays.fill(ht[k],0);}}
  st("Pose OK | haath: "+String.format("%.1f",best)+" (swing > 0.8)");}
}
